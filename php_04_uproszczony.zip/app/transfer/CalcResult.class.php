<?php
namespace app\transfer;

class CalcResult {
	public $op_name;
	public $result;	
} 